from lib import config as config_module
from lib import init_server
from lib import utils
from clore_hosting import main as clore_hosting
import asyncio, os
from lib import logging as logging_lib
config = config_module.config
log = logging_lib.log

auth = utils.get_auth()

if config.init_token:
    if auth=='':
        init_token = str(config.init_token)
        if len(init_token)==48:
            asyncio.run(init_server.init(init_token))
        else:
            print("\x1b[31mInvalid token\x1b[0m")
    else:
        print("\x1b[31mServer has already set up login credentials\x1b[0m")
elif config.reset:
    if auth=='':
        print("\x1b[31mCan't reset not logged in client\x1b[0m")
    else:
        res = utils.yes_no_question("\x1b[31mDo you really want to reset client?\x1b[0m\nIf you reset, authorization key will be dumped and you will never be able to login as the old server")
        if res:
            os.remove(config.auth_file)
            utils.run_command_v2("systemctl restart clore-hosting.service")
            log.success("Client login reseted")
elif config.service:
    if len(auth)==32+48+1:
        clore_client = clore_hosting.CloreClient(auth_key=auth)
        asyncio.run(clore_client.service())
    else:
        print("TODO: Firstly config auth")
else:
    print("Clore client help\n--init-token <token> (Initialize server)\n--reset (Remove current login)")