from lib import config as config_module
from lib import docker_interface
import docker
import time
import os

config = config_module.config

client = docker_interface.client

def stream_logs(container_name, sync_queue):
    try:
        container = client.containers.get(container_name)

        # Signal initialization
        sync_queue.put("I")
    
        # Stream new log entries
        for line in container.logs(stream=True, follow=True):
            sync_queue.put(f"S{line.decode('utf-8')}")
    except Exception as e:
        pass
    time.sleep(1)
    sync_queue.put(None)