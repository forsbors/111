from datetime import datetime
from lib import config as config_module
config = config_module.config

# lib.py
def time_str():
    return datetime.now().strftime("%d/%m %H:%M:%S")
class log:
    def success (message):
        ts = time_str()
        print(f"\033[92m{ts} | {message}\033[0m")
    def warning (message):
        ts = time_str()
        print(f"\033[33m{ts} | {message}\033[0m")
    def error (message):
        ts = time_str()
        print(f"\033[91m{ts} | {message}\033[0m")
    def info (message):
        ts = time_str()
        print(f"\033[94m{ts} | {message}\033[0m")
    def debug(message):
        if config.debug:
            ts = time_str()
            print(f"\033[97m{ts} | DEBUG | {message}\033[0m")