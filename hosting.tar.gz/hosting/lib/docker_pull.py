from lib import docker_interface
from lib import logging as logging_lib

import asyncio
import concurrent.futures
import time

log = logging_lib.log

async def pull_image(image_name, auth_config, log_dict, loop, pull_cancellation_event):
    def blocking_pull():
        client = docker_interface.low_level_client
        for line in client.pull(image_name, auth_config=auth_config, stream=True, decode=True):
            if pull_cancellation_event.is_set():
                log.debug(f"Canceling pull of \"{image_name}\"")
                break
            layer_id = line.get('id', 'general')
            status = line.get('status', '')
            progress = line.get('progress', '').strip()
            log_dict[layer_id] = f"{status} {progress}".strip()

    # Run the blocking pull operation in a separate thread
    with concurrent.futures.ThreadPoolExecutor() as pool:
        await loop.run_in_executor(pool, blocking_pull)