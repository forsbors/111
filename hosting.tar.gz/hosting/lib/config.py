import argparse
from types import SimpleNamespace

hard_config = {
    "local_ipv4_ranges": ["10.0.0.0/8","172.16.0.0/12","192.168.0.0/16","100.64.0.0/10"],
    "clore_network_name_prefix":"clore-",
    "clore_default_networks":[
        {
            "name": "clore-br0",
            "subnet": "172.18.0.0/16",
            "gateway": "172.18.0.1"
        }
    ],
    "run_iptables_with_sudo":True,
    "clore_iptables_rules":[
        "-A INPUT -s <subnet> -j DROP",
        "-I FORWARD -i <interface> -d <subnet> -j DROP"
    ],
    "clore_br_first_allowed_octet":"172",
    "ws_peers_recheck_interval": 300,
    "max_ws_peer_heartbeat_interval":200, # seconds
    "pull_log_streaming_interval": 450, # ms
    "log_containers_strings": False, # For debinging only
    "max_pull_logs_per_submit_run": {
        "instances":10,
        "size": 73728 # Characters
    },
    "max_remove_images_per_run": 2,
    "delete_unused_containers": True,
    "max_pull_log_size": 24576, # Characters
    "max_container_log_size": 262144, # Characters
    "container_log_streaming_interval": 2, # Seconds
    "maximum_service_loop_time": 900, # Seconds, failsafe variable - if service is stuck processing longer than this timeframe it will lead into restarting the app
    "maximum_pull_service_loop_time": 14400, # Exception for image pulling
    "creation_engine": "wrapper", # "wrapper" or "sdk" | Wrapper - wrapped docker cli, SDK - docker sdk
    "allow_mixed_gpus": True
}

parser = argparse.ArgumentParser(description='Example argparse usage')

# Add arguments
parser.add_argument('--service', action='store_true', help='Flag indicating service')
parser.add_argument('--reset', action='store_true', help='Reset init token')
parser.add_argument('--debug', action='store_true', help='Show Debug logs')
parser.add_argument('--init-token', type=str, help='Init token from clore.ai')
parser.add_argument('--auth-file', type=str, default="/opt/clore-hosting/client/auth", help='Auth file')
parser.add_argument('--startup-scripts-folder', type=str, default='/opt/clore-hosting/startup_scripts', help='Folder with startup scripts for containers')
parser.add_argument('--wireguard-config-folder', type=str, default='/opt/clore-hosting/wireguard/configs', help='Folder with wireguard configs')
parser.add_argument('--entrypoints-folder', type=str, default='/opt/clore-hosting/entrypoints', help='Folder with custom entrypoints')
parser.add_argument('--debug-ws-peer', type=str, help="Specific ws peer to connect to (for debugging only)")
parser.add_argument('--gpu-specs-file', type=str, default='/opt/clore-hosting/client/gpu_specs.json', help="Cache with specs of GPU possible OC/Power limit changes")
parser.add_argument('--extra-allowed-images-file', type=str, default="/opt/clore-hosting/extra_allowed_images.json", help="Docker image whitelist, that are allowed by clore.ai hosting software")

# Parse arguments, ignoring any non-defined arguments
args, _ = parser.parse_known_args()

config={}

for key in vars(args).keys():
    config[key]=vars(args)[key]
for key in hard_config.keys():
    config[key]=hard_config[key]

config = SimpleNamespace(**config)