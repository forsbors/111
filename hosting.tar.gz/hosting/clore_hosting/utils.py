import time
import re
from urllib.parse import urlparse

def is_valid_websocket_url(url):
    regex = r'^(ws|wss)://[a-zA-Z0-9-\.]+(:\d+)?(/.*)?$'
    if re.match(regex, url):
        parsed_url = urlparse(url)
        if parsed_url.scheme in ['ws', 'wss']:
            return True
    return False

def validate_hostname(hostname):
    # Define the regular expression pattern for a valid hostname
    pattern = re.compile(r'^[a-zA-Z0-9._-]{1,63}$')
    if pattern.match(hostname):
        return True
    else:
        return False

def unix_timestamp():
    return int(time.time())