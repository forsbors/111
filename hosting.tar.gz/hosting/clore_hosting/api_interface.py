import aiohttp
import asyncio
from clore_hosting import types

async def fetch_url(url, timeout=10):
    client_timeout = aiohttp.ClientTimeout(total=timeout)
    try:
        async with aiohttp.ClientSession(timeout=client_timeout) as session:
            async with session.get(url) as response:
                response.raise_for_status()
                return await response.json()
    except aiohttp.ClientError as e:
        return f"Client error occurred: {e}"
    except asyncio.TimeoutError:
        return "The request timed out."
    except Exception as e:
        return f"An error occurred: {e}"
    
async def get_server_config():
    direct_res = await fetch_url('https://api.clore.ai/server-config.json')
    if type(direct_res)==dict and "ws_peers" in direct_res and "allowed_images" in direct_res:
        return types.ServerConfig(**{
            "success": True,
            "ws_peers": direct_res["ws_peers"],
            "allowed_images": direct_res["allowed_images"]
        })
    else:
        return types.ServerConfig(**{
            "success": False,
            "ws_peers": [],
            "allowed_images": []
        })