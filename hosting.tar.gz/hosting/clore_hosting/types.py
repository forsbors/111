from pydantic import BaseModel
from typing import List, Any

class ServerConfig(BaseModel):
    success: bool
    ws_peers: List[Any]
    allowed_images: List[Any]

class DockerConfiguratorRes(BaseModel):
    validation_and_security: bool
    valid_containers: List[Any]
    use_hive_flightsheet: bool

class DeployContainersRes(BaseModel):
    all_running_container_names: List[str]
    all_stopped_container_names: List[str]